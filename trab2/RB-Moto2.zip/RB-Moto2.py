# -*- coding: utf-8 -*-
from gpiozero import OutputDevice
import time

# Definieren der Pins als OutputDevice-Instanzen
coil_A_1_pin = OutputDevice(24) # pink
coil_A_2_pin = OutputDevice(4)  # orange
coil_B_1_pin = OutputDevice(23) # blue
coil_B_2_pin = OutputDevice(25) # yellow
coil2_A_1_pin = OutputDevice(18) # pink
coil2_A_2_pin = OutputDevice(22) # orange
coil2_B_1_pin = OutputDevice(17) # blue
coil2_B_2_pin = OutputDevice(27) # yellow

StepCount = 8
Seq = list(range(0, StepCount))
Seq[0] = [0,1,0,0]
Seq[1] = [0,1,0,1]
Seq[2] = [0,0,0,1]
Seq[3] = [1,0,0,1]
Seq[4] = [1,0,0,0]
Seq[5] = [1,0,1,0]
Seq[6] = [0,0,1,0]
Seq[7] = [0,1,1,0]

def setStep(w1, w2, w3, w4):
    coil_A_1_pin.value = w1
    coil2_A_1_pin.value = w1
    coil_A_2_pin.value = w2
    coil2_A_2_pin.value = w2
    coil_B_1_pin.value = w3
    coil2_B_1_pin.value = w3
    coil_B_2_pin.value = w4
    coil2_B_2_pin.value = w4

def forward(delay, steps):
    for i in range(steps):
        for j in range(StepCount):
            setStep(Seq[j][0], Seq[j][1], Seq[j][2], Seq[j][3])
            time.sleep(delay)

def backwards(delay, steps):
    for i in range(steps):
        for j in reversed(range(StepCount)):
            setStep(Seq[j][0], Seq[j][1], Seq[j][2], Seq[j][3])
            time.sleep(delay)

# 20 slow steps forward
delay = 20
steps = 20
forward(delay / 1000.0, steps)
# 200 quick steps backwards
delay = 1
steps = 200
backwards(delay / 1000.0, steps)
